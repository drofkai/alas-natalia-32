#!/bin/bash
# Instala el fondo de pantalla que cambia durante el día.

cd "$(dirname "$0")" || exit 1
SRC="$(pwd)"

BASE="$HOME/Library/Application Support/FondoDinamico"
AGENTS="$HOME/Library/LaunchAgents"
LABEL="com.drofkai.fondodinamico"
PLIST="$AGENTS/$LABEL.plist"

echo "==> Instalando fondo dinámico..."

for f in imagenes/Sunset.png imagenes/day.png imagenes/Midnight.png cambiar_fondo.sh horarios.conf; do
  if [ ! -f "$SRC/$f" ]; then
    echo "Falta el archivo: $f"
    echo "Asegúrate de haber descomprimido TODA la carpeta antes de ejecutar."
    read -r -p "Presiona Enter para cerrar..." _
    exit 1
  fi
done

mkdir -p "$BASE/imagenes" "$AGENTS"
cp "$SRC"/imagenes/*.png "$BASE/imagenes/"
cp "$SRC/cambiar_fondo.sh" "$BASE/cambiar_fondo.sh"
chmod +x "$BASE/cambiar_fondo.sh"
# No pisar horarios si ya los editaste antes
[ -f "$BASE/horarios.conf" ] || cp "$SRC/horarios.conf" "$BASE/horarios.conf"

cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>$LABEL</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>$BASE/cambiar_fondo.sh</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>StartInterval</key>
  <integer>300</integer>
  <key>StandardErrorPath</key>
  <string>$BASE/log.txt</string>
</dict>
</plist>
EOF

# Reiniciar el agente si ya existía
launchctl bootout "gui/$(id -u)/$LABEL" >/dev/null 2>&1
launchctl unload "$PLIST" >/dev/null 2>&1
if ! launchctl bootstrap "gui/$(id -u)" "$PLIST" >/dev/null 2>&1; then
  launchctl load "$PLIST" >/dev/null 2>&1
fi

# Aplicar de inmediato la imagen que corresponde a esta hora
FORCE=1 /bin/bash "$BASE/cambiar_fondo.sh"

echo ""
echo "Listo. Tu fondo cambiará solo según los horarios de:"
echo "  $BASE/horarios.conf"
echo ""
echo "Si no cambió el fondo ahora, revisa el archivo log.txt en esa misma carpeta."
echo ""
read -r -p "Presiona Enter para cerrar..." _
