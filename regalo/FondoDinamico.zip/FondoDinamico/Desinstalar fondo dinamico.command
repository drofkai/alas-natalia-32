#!/bin/bash
# Quita el fondo dinámico y borra lo que se instaló.

BASE="$HOME/Library/Application Support/FondoDinamico"
LABEL="com.drofkai.fondodinamico"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"

echo "==> Desinstalando fondo dinámico..."

launchctl bootout "gui/$(id -u)/$LABEL" >/dev/null 2>&1
launchctl unload "$PLIST" >/dev/null 2>&1
rm -f "$PLIST"
rm -rf "$BASE"

echo ""
echo "Listo. Ya no cambiará más."
echo "El fondo actual se queda puesto: para cambiarlo, ve a"
echo "Preferencias del Sistema > Escritorio y salvapantallas."
echo ""
read -r -p "Presiona Enter para cerrar..." _
