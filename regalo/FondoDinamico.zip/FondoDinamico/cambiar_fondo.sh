#!/bin/bash
# Cambia el fondo de pantalla según la hora, usando horarios.conf
# (Se ejecuta automáticamente cada pocos minutos y al iniciar sesión.)

BASE="$HOME/Library/Application Support/FondoDinamico"
CONF="$BASE/horarios.conf"
IMG_DIR="$BASE/imagenes"
STATE="$BASE/ultimo.txt"

# Hora actual en minutos desde medianoche (NOW_HM="HH:MM" sirve solo para pruebas)
if [ -n "$NOW_HM" ]; then
  now=$((10#${NOW_HM%%:*} * 60 + 10#${NOW_HM##*:}))
else
  now=$((10#$(date +%H) * 60 + 10#$(date +%M)))
fi

best_t=-1; best_f=""
last_t=-1; last_f=""

while read -r hm file; do
  hm="${hm%$'\r'}"; file="${file%$'\r'}"
  case "$hm" in ""|\#*) continue;; esac
  case "$hm" in *:*) ;; *) continue;; esac
  t=$((10#${hm%%:*} * 60 + 10#${hm##*:}))
  # Imagen que corresponde ahora: el horario más reciente que ya pasó
  if [ "$t" -le "$now" ] && [ "$t" -gt "$best_t" ]; then best_t=$t; best_f="$file"; fi
  # Imagen del último horario del día (sirve para antes del primer horario)
  if [ "$t" -gt "$last_t" ]; then last_t=$t; last_f="$file"; fi
done < "$CONF"

[ -z "$best_f" ] && best_f="$last_f"
path="$IMG_DIR/$best_f"

if [ "$DRY_RUN" = "1" ]; then
  echo "$best_f"
  exit 0
fi

if [ ! -f "$path" ]; then
  echo "No encuentro la imagen: $path" >&2
  exit 1
fi

# Si ya está puesta esa imagen, no hacer nada (evita parpadeos)
if [ "$FORCE" != "1" ] && [ "$(cat "$STATE" 2>/dev/null)" = "$best_f" ]; then
  exit 0
fi

# Método 1: API de macOS (no pide permisos), aplica a todas las pantallas
ok=$(IMG_PATH="$path" osascript -l JavaScript <<'JXA' 2>/dev/null
ObjC.import('AppKit');
ObjC.import('Foundation');
var env = $.NSProcessInfo.processInfo.environment;
var p = ObjC.unwrap(env.objectForKey('IMG_PATH'));
var ws = $.NSWorkspace.sharedWorkspace;
var screens = $.NSScreen.screens;
var url = $.NSURL.fileURLWithPath(p);
var good = 0;
for (var i = 0; i < screens.count; i++) {
  var r = ws.setDesktopImageURLForScreenOptionsError(url, screens.objectAtIndex(i), $.NSDictionary.dictionary, $());
  if (r) good++;
}
good;
JXA
)

# Método 2 (respaldo): System Events
if [ -z "$ok" ] || [ "$ok" = "0" ]; then
  osascript -e "tell application \"System Events\" to tell every desktop to set picture to POSIX file \"$path\"" >/dev/null 2>&1 || exit 1
fi

echo "$best_f" > "$STATE"
exit 0
